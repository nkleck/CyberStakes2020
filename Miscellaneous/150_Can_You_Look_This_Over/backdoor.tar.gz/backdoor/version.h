/* $OpenBSD: version.h,v 1.67 2013/07/25 00:57:37 djm Exp $ */

#define SSH_VERSION	"OpenSSH_6.3"

#define SSH_PORTABLE	"p1"
#define SSH_RELEASE	SSH_VERSION SSH_PORTABLE
