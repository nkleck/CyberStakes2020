<?php 

function parseXml($doc) {
	libxml_disable_entity_loader(false);
	$dom = new DOMDocument();
	if (!$dom->loadXML($doc, LIBXML_NOENT | LIBXML_DTDLOAD)) {
		die('error loading xml (1)');
	}

	$result = simplexml_import_dom($dom);
	if (!$result) {
		die('error loading xml (2)');
	}

	return $result;
}

function readCreds() {
	$myfile = fopen("creds.xml", "r");
	if (!$myfile) {
		die("error loading creds");
	}

	$contents = fread($myfile, filesize("creds.xml"));
	if (!$contents) {
		die('error reading creds');
	}

	fclose($myfile);
	return $contents;
}

function login($user, $pass) {
	$xml = new SimpleXMLElement(readCreds());
	$result = $xml->xpath("/creds[./user = '$user' and ./pass = '$pass']");
	if ($result) {
		$_SESSION['auth'] = 1;
		header("Location: /");
	} else {
		echo "error: invalid credentials";
	}
}

function logout() {
	unset($_SESSION['auth']);
	header("Location: /");
}

?>
