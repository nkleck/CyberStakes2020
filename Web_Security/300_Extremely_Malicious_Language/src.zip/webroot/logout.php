<?php

require 'funcs.php';
session_start();
logout();
