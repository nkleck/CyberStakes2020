<?php
require 'funcs.php';
session_start();
?>

<html>
	<head>
		<title>CYBER MAP</title>
		<style>
			body {
				height: 100%;
				width: 100%;
				background-color: #00004d;
			}
		</style>
	</head>
	<body>
<?php if (isset($_SESSION['auth']) && $_SESSION['auth']) : ?>
	<form method="POST" action="logout.php">
		<input type="submit" value="LOGOUT">
	</form>
	<form method="POST" action="genmap.php">
		<textarea name="xmlol" rows=20 cols=100><cybermap>
	<name>CYBER MAP</name>
	<country>CN</country>
	<country>US</country>
</cybermap></textarea>
		<input type="submit" value="GENERATE">
	</form>
	
<?php else : ?>
	<form method="POST" action="login.php">
		<input type="text" name="username">
		<input type="password" name="password">
		<input type="submit" value="LOGIN">
	</form>
<?php endif ?>
	</body>
</html>