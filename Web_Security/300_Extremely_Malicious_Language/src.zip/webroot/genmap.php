<?php
require 'funcs.php';
session_start();

function genmap($xml) {
	$mapConfig = parseXml($xml);

	if (!isset($mapConfig->name)) {
		die("needs &lt;name&gt;");
	} 

	if (!isset($mapConfig->country)) {
		die("needs at least one &lt;country&gt;");
	}

	if (is_string($mapConfig["country"])) {
		$mapConfig["country"] = array($mapConfig["country"]);
	}

	$validated = array();
	foreach($mapConfig->country as $country) {
		if (preg_match('/[A-Z]{2}/', $country)) 
		{
			array_push($validated, $country);
		} 
	}

	if (count($validated) < 1) {
		die("needs at least one &lt;country&gt;");
	}

	$target = "challenge.acictf.com:45111/make.php?country[]=" . join("&country[]=", $validated) . "&name=" . urlencode($mapConfig->name);
	$ch = curl_init();
	if (!$ch) {
		die('error initializing curl');
	}

	if (!curl_setopt($ch, CURLOPT_URL, $target)) {
		die('error setting target in curl');
	}
	
	if (!curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1)) {
		die('error setting opt in curl');
	}

	$output = curl_exec($ch);

	if (!$output) {
		die('error generating map');
	}

	curl_close($ch);

	echo $output;
}

genmap($_POST['xmlol']);