<?php

require 'funcs.php';
session_start();
login($_POST["username"], $_POST["password"]);